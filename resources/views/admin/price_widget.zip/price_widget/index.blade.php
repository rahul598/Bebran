@extends('layouts.admin')
@section('more-css')
<style>
    .dataTables_filter{
        display:none;
    }
</style>
@endsection
@section('content')
@php
$user_status_array = unserialize(User_Status_Array);
@endphp
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">{{ __('Price Widget') }} </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="{{url('admin')}}">{{ __('Home') }}</a></li>
          <li class="breadcrumb-item active">{{ __('Price Widget') }}</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      @include('admin.message') 
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Listing</h3>
            <div class="card-tools listing_page">
               
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive">
        <table id="example2" class="table table-bordered table-hover dataTable">
          <thead>
            <tr>
                <th>Id</th>
                <th>Service Name</th> 
                <th>Action</th> 
            </tr>
          </thead>
          <tbody>
              @php $row = 1 @endphp
              @foreach($lists as $key => $val)
              @php $service = DB::table('pages')->where('id', $val['service_type'])->first(); @endphp
           <tr>
                <td>{{ $row++ }}</td>
                <td>{{  $service->page_name }}</td> 
                <td>
                    <a href="{{ url(Admin_Prefix.'price_widget_list/edit/'.$val['service_type']) }}" title="Edit" class="btn btn-success"><i class="fa fa-fw fa-edit"></i></a>
                    <a href="{{ route('price_widget_delete', ['id'=>$val['service_type']]) }}" data-confirm="" title="Delete" class="btn btn-danger"><i class="fa fa-fw fa-window-close"></i></a> 
                     
                </td> 
            </tr> 
            @endforeach
        </tbody>
      </table>
 
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->

      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
</section>
<!-- /.content -->
@endsection
@section('more-scripts')
<script>
    
    $(document).ready(function(){
         $('.dataTable').dataTable({
             searching: false
         });
    });
</script>
@endsection
