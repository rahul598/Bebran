@extends('layouts.admin')
<style>
    .price_widger_container label {
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        .btnRemove{
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
        }
        .form-check{ 
            display: flex !important;
            justify-content: stretch !important; 
            align-items: flex-end !important;
        } 
        .btnAdd{
            width:100px;
        }
  </style>
@section('content') 
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">{{ __('Add Plan') }}</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{url('admin')}}">{{ __('Home') }}</a></li>
            <li class="breadcrumb-item active">{{ __('Add Plan') }}</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  
<!-- Main content -->
<section class="content">
  <div class="container-fluid price_widger_container">
    <div class="row card card-primary p-3 shadow mt-4 border-0">
        <div class="col-md-4 pl-0 mb-3">
            <label for="plan" class="text-primary">Relatived Pricing Packages</label> 
        @php $service = DB::table('pages')->where('id', $services[0]['service_page_id'])->first(); @endphp
         <input class="form-control service" type="text" name="service" value="{{ $service->page_name }}" readonly disabled />
        
        </div>
      @include('admin.message')   
          <!-- /.features card-header -->
           <div class="row">
            <form action="{{ route('feature_list_update', ['id'=> $services[0]['service_page_id']]) }}" method="post">
                @csrf
                <input type="hidden" name="package_id" value="{{$services[0]['service_page_id']}}" class="package_id">
                @foreach($lists as $key => $value)
                <div class="col-md-12 mb-4 card shadow p-3 mt-4 border-0 feature_row">
                    <div class="row justify-content-between">
                        <div class="col-md-4 mb-3">
                            <label for="planDuration">Feature Heading</label>
                            <input class="form-control discountPrice" type="text" value="{{old('heading_price_widget', $value['heading'])}}" name="heading_price_widget[{{$value['id']}}]" id="discountPrice" />
                        </div>
                        <div class="col-md-2 d-none">
                            <div class="d-flex flex-column mx-5 px-4">
                                <label class="invisible">1</label>
                                <a class="btn btn-success btnRow" href="javascript:void(0);">
                                    <i class="fas fa-plus"></i> 
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="detail_table">
                        <table class="table table-borderless">
                            <thead>
                                <tr class="text-center">
                                    <th scope="col">Sub Heading</th>
                                    <th scope="col">Lite</th>
                                    <th scope="col">Standard</th>
                                    <th scope="col">Advance</th>
                                    <th scope="col">Enterprise</th>
                                    <th scope="col"> </th>
                                </tr>
                            </thead>
                            <tbody class="show_itm">
                                <tr>
                                    <td>
                                        @php $subheading = json_decode($value['subheading']); 
                                         
                                        @endphp
                                        @foreach($subheading as $sub => $subhead)
                                        <input class="form-control mainPrice mb-4" type="text" value="{{old('subheading', $subhead)}}"name="subheading_price_widget[{{$value['id']}}][]" />
                                        @endforeach
                                    </td>
                                    <td>
                                        @php $lite = json_decode($value['lite']); @endphp
                                        @foreach($lite as $litekey => $liteval)
                                        <input class="form-control mainPrice description" type="text" value="{{old('lite', $liteval)}}" name="lite[{{$value['id']}}][]"  @if(isset($liteval) && $liteval == 1) disabled @endif />
                                        
                                        <div class="form-check mb-4">
                                            <label class="form-check-label" for="flexCheckDefault">For Icon</label>
                                            <input class="form-check-input umlimited" type="checkbox" value="{{ old('lite', isset($liteval) && $liteval == 1 ? 1 : 0) }}" name="lite[{{$value['id']}}][]" id="flexCheckChecked" @if(isset($liteval) && $liteval == 1) checked @endif >
                                        </div>
                                        @endforeach
                                    </td>
                                    <td>
                                        @php $standard = json_decode($value['standard']); @endphp
                                        @foreach($standard as $standardkey => $standardval)
                                        <input class="form-control mainPrice description" value="{{old('standard', $standardval)}}" type="text" name="standard[{{$value['id']}}][]" @if(isset($standardval) && $standardval == 1) disabled @endif/>
                                        <div class="form-check mb-4">
                                            <label class="form-check-label" for="flexCheckDefault">For Icon</label>
                                            <input class="form-check-input umlimited" type="checkbox" value="{{ old('standard', isset($standardval) && $standardval == 1 ? 1 : 0) }}" name="standard[{{$value['id']}}][]" id="flexCheckChecked" @if(isset($standardval) && $standardval == 1) checked @endif >
                                        </div>
                                        @endforeach
                                    </td>
                                    <td>
                                        @php $advance = json_decode($value['advance']); @endphp
                                        @foreach($advance as $advancekey => $advanceval)
                                        <input class="form-control mainPrice description" value="{{old('advance', $advanceval)}}" type="text" name="advance[{{$value['id']}}][]" @if(isset($advanceval) && $advanceval == 1) disabled @endif/>
                                        <div class="form-check mb-4">
                                            <label class="form-check-label" for="flexCheckDefault">For Icon</label>
                                            <input class="form-check-input umlimited" type="checkbox" value="{{ old('advance', isset($advanceval) && $advanceval == 1 ? 1 : 0) }}" name="advance[{{$value['id']}}][]" id="flexCheckChecked" @if(isset($advanceval) && $advanceval == 1) checked @endif >
                                        </div>
                                        @endforeach
                                    </td>
                                    <td>
                                        @php $enterprise = json_decode($value['enterprise']); @endphp
                                        @foreach($enterprise as $enterprisekey => $enterpriseval)
                                        <input class="form-control mainPrice description"  value="{{old('enterprise', $enterpriseval)}}" type="text" name="enterprise[{{$value['id']}}][]" @if(isset($enterpriseval) && $enterpriseval == 1) disabled @endif/>
                                        <div class="form-check mb-4">
                                            <label class="form-check-label" for="flexCheckDefault">For Icon</label>
                                            <input class="form-check-input umlimited" type="checkbox" value="{{ old('enterprise', isset($enterpriseval) && $enterpriseval == 1 ? 1 : 0) }}" name="enterprise[{{$value['id']}}][]" id="flexCheckChecked" @if(isset($enterpriseval) && $enterpriseval == 1) checked @endif>
                                        </div>
                                        @endforeach
                                    </td>
                                    <td class="d-none">
                                        <a class="btn btn-primary btnAdd" href="javascript:void(0);">
                                            <i class="fas fa-plus-lg"></i> Add Plan
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                @endforeach
                <input type="submit" value="Save Plan Features" class="btn btn-success" name="submit">
            </form>
        </div>
      </div>
      <!-- /.row -->
  </div>
</section>
 
@endsection


@section('more-scripts')
<script>
    $(document).ready(function(){
        // disbabled input
        $(document).on("click", ".umlimited", function () {
          var descriptionInput = $(this).parent().siblings(".description");

          // Disable or enable the description input based on checkbox state
          descriptionInput.prop("disabled", $(this).is(":checked"));

          // Clear error message if checkbox is checked
          if ($(this).is(":checked")) {
            descriptionInput.siblings(".error_msg").html("");
            descriptionInput.val("");
          }
        });  
    });
</script>
@endsection



