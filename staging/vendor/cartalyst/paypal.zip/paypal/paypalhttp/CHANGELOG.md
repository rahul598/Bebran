## 1.0.1
* Fix Case Sensitivity of Content Type for deserialization process

## 1.0.0
- First release
